export type Wskaznik = 'POLSTR_1M' | 'WIBOR_3M';
export type TypRaty = 'rowne' | 'malejace';
export type EfektNadplaty = 'rata' | 'okres';

export interface Nadplata { nrRaty: number; kwota: number; efekt: EfektNadplaty }

export interface HarmonogramRequest {
  kwota: number;
  liczbaRat: number;
  dataPierwszejRaty: string; // YYYY-MM-DD
  wskaznik: Wskaznik;
  wartoscWskaznika: number; // %
  marza: number; // %
  typRaty: TypRaty;
  nadplaty: Nadplata[];
}

export interface PozycjaHarmonogramu {
  nr: number; data: string; kapital: number; odsetki: number; rata: number; nadplata: number; saldo: number;
}

export interface HarmonogramResponse {
  oprocentowanie: number;
  harmonogram: PozycjaHarmonogramu[];
  podsumowanie: {
    rataPierwsza: number; rataOstatnia: number; sumaOdsetek: number; lacznieDoSplaty: number;
    sumaNadplat: number; oszczednoscOdsetek: number; skrocenieRat: number; rataStresTest: number;
  };
}

export const WSKAZNIKI: Record<Wskaznik, { label: string; domyslnie: number }> = {
  POLSTR_1M: { label: 'POLSTR 1M', domyslnie: 3.85 },
  WIBOR_3M: { label: 'WIBOR 3M', domyslnie: 4.21 },
};

export function walidacja(r: HarmonogramRequest): string[] {
  const e: string[] = [];
  if (!(r.kwota >= 50_000 && r.kwota <= 5_000_000)) e.push('kwota');
  if (!Number.isInteger(r.liczbaRat) || r.liczbaRat < 12 || r.liczbaRat > 420) e.push('liczbaRat');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(r.dataPierwszejRaty)) e.push('dataPierwszejRaty');
  if (!(r.wskaznik in WSKAZNIKI)) e.push('wskaznik');
  if (!(r.marza >= 0 && r.marza <= 10)) e.push('marza');
  if (r.typRaty !== 'rowne' && r.typRaty !== 'malejace') e.push('typRaty');
  r.nadplaty.forEach((n, i) => { if (n.nrRaty < 1 || n.nrRaty > r.liczbaRat || n.kwota <= 0) e.push(`nadplaty.${i}`); });
  return e;
}

export function dodajMiesiace(iso: string, k: number): string {
  const [y, m, d] = iso.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1 + k, 1));
  const last = new Date(Date.UTC(dt.getUTCFullYear(), dt.getUTCMonth() + 1, 0)).getUTCDate();
  dt.setUTCDate(Math.min(d, last));
  return dt.toISOString().slice(0, 10);
}

const zaokr = (v: number) => Math.round(v * 100) / 100;

function symuluj(req: HarmonogramRequest, roczna: number, nadplaty: Nadplata[]): PozycjaHarmonogramu[] {
  const n = req.liczbaRat, r = roczna / 100 / 12;
  const ann = (b: number, k: number) => (r === 0 ? b / k : (b * r) / (1 - Math.pow(1 + r, -k)));
  let saldo = req.kwota, rata = ann(saldo, n), kapStaly = saldo / n;
  const out: PozycjaHarmonogramu[] = [];
  for (let i = 1; i <= n && saldo > 0.005; i++) {
    const ods = saldo * r;
    const kap = Math.min(req.typRaty === 'rowne' ? rata - ods : kapStaly, saldo);
    saldo -= kap;
    const teraz = nadplaty.filter((x) => x.nrRaty === i);
    let nad = 0;
    for (const x of teraz) { const a = Math.min(x.kwota, saldo); nad += a; saldo -= a; }
    out.push({ nr: i, data: dodajMiesiace(req.dataPierwszejRaty, i - 1), kapital: zaokr(kap), odsetki: zaokr(ods), rata: zaokr(kap + ods), nadplata: zaokr(nad), saldo: zaokr(Math.max(0, saldo)) });
    const pozostalo = n - i;
    if (nad > 0 && pozostalo > 0 && teraz.some((x) => x.efekt === 'rata')) {
      if (req.typRaty === 'rowne') rata = ann(saldo, pozostalo); else kapStaly = saldo / pozostalo;
    }
  }
  return out;
}

export function policzHarmonogram(req: HarmonogramRequest): HarmonogramResponse {
  const opr = req.wartoscWskaznika + req.marza;
  const h = symuluj(req, opr, req.nadplaty);
  const bazowy = symuluj(req, opr, []);
  const stres = symuluj(req, opr + 2.5, []);
  const suma = (a: PozycjaHarmonogramu[], k: keyof PozycjaHarmonogramu) => a.reduce((t, x) => t + (x[k] as number), 0);
  const sumaOdsetek = suma(h, 'odsetki');
  return {
    oprocentowanie: opr,
    harmonogram: h,
    podsumowanie: {
      rataPierwsza: h[0].rata,
      rataOstatnia: h[h.length - 1].rata,
      sumaOdsetek: zaokr(sumaOdsetek),
      lacznieDoSplaty: zaokr(req.kwota + sumaOdsetek),
      sumaNadplat: zaokr(suma(h, 'nadplata')),
      oszczednoscOdsetek: zaokr(suma(bazowy, 'odsetki') - sumaOdsetek),
      skrocenieRat: bazowy.length - h.length,
      rataStresTest: stres[0].rata,
    },
  };
}
