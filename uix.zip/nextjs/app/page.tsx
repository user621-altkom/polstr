'use client';

import { useMemo, useState, type FormEvent } from 'react';
import { Barlow, Barlow_Condensed } from 'next/font/google';
import {
  WSKAZNIKI, type EfektNadplaty, type HarmonogramRequest, type HarmonogramResponse, type TypRaty, type Wskaznik,
} from '@/lib/harmonogram';

const body = Barlow({ subsets: ['latin', 'latin-ext'], weight: ['400', '500', '600'], variable: '--font-body' });
const head = Barlow_Condensed({ subsets: ['latin', 'latin-ext'], weight: ['500', '600', '700'], variable: '--font-head' });

type NadplataUI = { id: number; nrRaty: number; kwota: number; efekt: EfektNadplaty };
type Form = Omit<HarmonogramRequest, 'nadplaty'> & { nadplaty: NadplataUI[] };

const PRZYKLADY: { label: string; v: Form }[] = [
  { label: 'Mieszkanie 600 tys.', v: { kwota: 600_000, liczbaRat: 300, dataPierwszejRaty: '2026-11-10', wskaznik: 'POLSTR_1M', wartoscWskaznika: 3.85, marza: 2.0, typRaty: 'rowne', nadplaty: [{ id: 1, nrRaty: 24, kwota: 50_000, efekt: 'okres' }] } },
  { label: 'Dom 1,2 mln', v: { kwota: 1_200_000, liczbaRat: 360, dataPierwszejRaty: '2026-12-05', wskaznik: 'POLSTR_1M', wartoscWskaznika: 3.85, marza: 1.85, typRaty: 'rowne', nadplaty: [{ id: 2, nrRaty: 36, kwota: 100_000, efekt: 'rata' }, { id: 3, nrRaty: 60, kwota: 100_000, efekt: 'okres' }] } },
  { label: 'Kawalerka 350 tys.', v: { kwota: 350_000, liczbaRat: 240, dataPierwszejRaty: '2026-11-15', wskaznik: 'WIBOR_3M', wartoscWskaznika: 4.21, marza: 2.2, typRaty: 'malejace', nadplaty: [] } },
];

const pln = (v: number, d = 2) => v.toLocaleString('pl-PL', { minimumFractionDigits: d, maximumFractionDigits: d });
const dataPL = (iso: string) => iso.split('-').reverse().join('.');

const inputCls = 'w-full min-h-[42px] rounded-md border border-[#1d1f20]/15 bg-white px-3 text-[15px] text-[#1d1f20] transition hover:border-[#1d1f20]/45 focus:border-[#5980a6] focus:outline-none focus:ring-[3px] focus:ring-[#d6ebff]';
const labelCls = 'text-[13px] font-semibold text-[#2b2b2d]';
const kicker = 'text-xs font-semibold uppercase tracking-[0.1em]';

function Corners() {
  const c = 'pointer-events-none absolute h-[11px] w-[11px] before:absolute before:left-[5px] before:top-0 before:h-full before:w-px before:bg-current after:absolute after:left-0 after:top-[5px] after:h-px after:w-full after:bg-current text-[#1d1f20]/55';
  return (<>
    <i className={`${c} -left-[6px] -top-[6px]`} /><i className={`${c} -right-[6px] -top-[6px]`} />
    <i className={`${c} -bottom-[6px] -left-[6px]`} /><i className={`${c} -bottom-[6px] -right-[6px]`} />
  </>);
}

function Seg<T extends string>({ value, options, onChange, name }: { value: T; options: { v: T; l: string }[]; onChange: (v: T) => void; name: string }) {
  return (
    <div role="radiogroup" className="flex min-h-[42px] overflow-hidden rounded-md border border-[#1d1f20]/15 bg-white">
      {options.map((o, i) => (
        <label key={o.v} className={`flex flex-1 cursor-pointer items-center justify-center text-sm transition has-[:focus-visible]:outline has-[:focus-visible]:outline-2 has-[:focus-visible]:-outline-offset-2 has-[:focus-visible]:outline-[#5980a6] ${i ? 'border-l border-[#1d1f20]/15' : ''} ${value === o.v ? 'bg-[#5980a6] text-white' : 'hover:bg-[#1d1f20]/[0.07]'}`}>
          <input type="radio" name={name} className="sr-only" checked={value === o.v} onChange={() => onChange(o.v)} />{o.l}
        </label>
      ))}
    </div>
  );
}

function Stat({ label, value, unit, sub, tone }: { label: string; value: string; unit: string; sub: string; tone: 'blue' | 'graphite' | 'dark' }) {
  const t = {
    blue: { box: 'bg-white border-[#1d1f20]/15', k: 'text-[#416180]', dot: 'bg-[#416180]', v: 'text-[#1d2d3d] text-[52px]', u: 'text-[#2c455d]', s: 'text-[#424244]' },
    graphite: { box: 'bg-white border-[#1d1f20]/15', k: 'text-[#424244]', dot: 'bg-[#2b2b2d]', v: 'text-[#2b2b2d] text-[44px]', u: 'text-[#424244]', s: 'text-[#424244]' },
    dark: { box: 'bg-[#2b2b2d] border-[#2b2b2d]', k: 'text-[#d4d4d7]', dot: 'bg-white', v: 'text-white text-[44px]', u: 'text-[#d4d4d7]', s: 'text-[#d4d4d7]' },
  }[tone];
  return (
    <div className={`relative flex flex-col gap-2.5 border p-[22px] ${t.box}`}>
      <Corners />
      <div className={`flex items-center gap-2 ${kicker} ${t.k}`}><i className={`h-2 w-2 rounded-full ${t.dot}`} />{label}</div>
      <div className="flex flex-wrap items-baseline gap-2">
        <span className={`font-[family-name:var(--font-head)] font-bold leading-none tracking-[-0.01em] tabular-nums ${t.v}`}>{value}</span>
        <span className={`font-[family-name:var(--font-head)] text-xl font-semibold ${t.u}`}>{unit}</span>
      </div>
      <span className={`text-[13px] ${t.s}`}>{sub}</span>
    </div>
  );
}

export default function Page() {
  const [form, setForm] = useState<Form>(PRZYKLADY[0].v);
  const [wynik, setWynik] = useState<HarmonogramResponse | null>(null);
  const [liczonoDla, setLiczonoDla] = useState<string | null>(null);
  const [ladowanie, setLadowanie] = useState(false);
  const [blad, setBlad] = useState<string | null>(null);
  const [widok, setWidok] = useState<'rok' | 'mies'>('rok');
  const [rok, setRok] = useState(1);

  const klucz = JSON.stringify(form);
  const nieaktualne = liczonoDla !== null && liczonoDla !== klucz;
  const set = <K extends keyof Form>(k: K, v: Form[K]) => setForm((f) => ({ ...f, [k]: v }));
  const setNad = (id: number, p: Partial<NadplataUI>) => set('nadplaty', form.nadplaty.map((n) => (n.id === id ? { ...n, ...p } : n)));

  const bledy = {
    kwota: form.kwota < 50_000 || form.kwota > 5_000_000,
    liczbaRat: !Number.isInteger(form.liczbaRat) || form.liczbaRat < 12 || form.liczbaRat > 420,
    nad: form.nadplaty.map((n) => n.nrRaty < 1 || n.nrRaty > form.liczbaRat || n.kwota <= 0),
  };
  const maBledy = bledy.kwota || bledy.liczbaRat || bledy.nad.some(Boolean);

  async function policz(e?: FormEvent) {
    e?.preventDefault();
    if (maBledy) return;
    setLadowanie(true); setBlad(null);
    try {
      const payload: HarmonogramRequest = { ...form, nadplaty: form.nadplaty.map(({ id, ...n }) => n) };
      const res = await fetch('/api/harmonogram', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
      if (!res.ok) throw new Error(`Błąd serwera (${res.status})`);
      setWynik(await res.json()); setLiczonoDla(klucz); setRok(1);
    } catch (err) {
      setBlad(err instanceof Error ? err.message : 'Nie udało się pobrać harmonogramu');
    } finally { setLadowanie(false); }
  }

  function eksportujCsv() {
    if (!wynik) return;
    const f = (v: number) => v.toFixed(2).replace('.', ',');
    const lines = ['Nr;Data;Kapitał;Odsetki;Rata;Nadpłata;Saldo po spłacie',
      ...wynik.harmonogram.map((x) => [x.nr, dataPL(x.data), f(x.kapital), f(x.odsetki), f(x.rata), f(x.nadplata), f(x.saldo)].join(';'))];
    const url = URL.createObjectURL(new Blob(['\ufeff' + lines.join('\n')], { type: 'text/csv;charset=utf-8' }));
    const a = document.createElement('a'); a.href = url; a.download = 'harmonogram-splaty.csv'; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  const h = wynik?.harmonogram ?? [];
  const lat = Math.max(1, Math.ceil(h.length / 12));
  const wiersze = useMemo(() => {
    if (widok === 'mies') return h.slice((rok - 1) * 12, rok * 12).map((x) => ({ key: x.nr, nr: String(x.nr), data: dataPL(x.data), kap: pln(x.kapital), ods: pln(x.odsetki), rata: pln(x.rata), nad: x.nadplata, saldo: pln(x.saldo), ost: x.nr === h.length }));
    return Array.from({ length: lat }, (_, y) => {
      const g = h.slice(y * 12, y * 12 + 12), s = (k: 'kapital' | 'odsetki' | 'rata' | 'nadplata') => g.reduce((t, x) => t + x[k], 0);
      return { key: y, nr: String(y + 1), data: `${dataPL(g[0].data)} – ${dataPL(g[g.length - 1].data)}`, kap: pln(s('kapital'), 0), ods: pln(s('odsetki'), 0), rata: pln(s('rata'), 0), nad: s('nadplata'), saldo: pln(g[g.length - 1].saldo, 0), ost: y === lat - 1 };
    });
  }, [h, widok, rok, lat]);

  const p = wynik?.podsumowanie;
  const odmiana = (n: number) => (n === 1 ? 'ratę' : n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 10 || n % 100 >= 20) ? 'raty' : 'rat');

  return (
    <div className={`${body.variable} ${head.variable} min-h-screen bg-[#f2f2f3] font-[family-name:var(--font-body)] text-[#1d1f20]`}>
      <nav className="flex items-center gap-6 border-b border-[#1d1f20]/15 bg-white px-6 py-3.5 md:px-10">
        <div className="mr-auto flex items-center gap-2.5 font-[family-name:var(--font-head)] text-[22px] font-semibold tracking-[0.02em]">
          <span className="h-[22px] w-[22px] border-[1.5px] border-[#5980a6]" />BANK HIPOTEKA
        </div>
        {['Kredyty', 'Kalkulator', 'Oferta', 'Kontakt'].map((l) => (
          <a key={l} href="#" className={`hidden text-sm hover:text-[#5980a6] sm:block ${l === 'Kalkulator' ? 'text-[#5980a6]' : ''}`}>{l}</a>
        ))}
      </nav>

      <main className="mx-auto flex w-full max-w-[1320px] flex-col gap-9 px-6 pb-16 pt-10 md:px-10">
        <header className="flex flex-wrap items-end justify-between gap-6">
          <div className="flex flex-col gap-1.5">
            <div className={`${kicker} tracking-[0.14em] text-[#416180]`}>Kredyt hipoteczny · zmienne oprocentowanie</div>
            <h1 className="font-[family-name:var(--font-head)] text-4xl font-semibold uppercase leading-none tracking-[-0.01em] md:text-[52px]">Kalkulator rat POLSTR 1M / WIBOR 3M</h1>
          </div>
          <p className="max-w-[380px] text-sm leading-normal text-[#424244] [text-wrap:pretty]">Wprowadź parametry i kliknij „Policz”. Wyliczenie ma charakter poglądowy i nie stanowi oferty.</p>
        </header>

        <div className="flex flex-wrap items-start gap-7">
          <form onSubmit={policz} className="relative flex min-w-0 flex-[1_1_420px] flex-col gap-[22px] border border-[#1d1f20]/15 bg-white p-5 md:p-7">
            <Corners />
            <div className="flex items-baseline gap-2.5">
              <span className="font-[family-name:var(--font-head)] text-[13px] font-semibold text-[#416180]">01</span>
              <h2 className="font-[family-name:var(--font-head)] text-2xl font-semibold uppercase">Parametry kredytu</h2>
            </div>

            <div className="flex flex-col gap-2">
              <span className={`${kicker} font-normal text-[#5d5d60]`}>Przykładowe dane</span>
              <div className="flex flex-wrap gap-2">
                {PRZYKLADY.map((x) => {
                  const on = JSON.stringify(x.v) === klucz;
                  return <button key={x.label} type="button" onClick={() => setForm(structuredClone(x.v))} className={`rounded-full border px-3.5 py-[7px] text-[13px] font-medium transition hover:border-[#416180] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#5980a6] ${on ? 'border-[#416180] bg-[#416180] text-white' : 'border-[#1d1f20]/15 bg-white text-[#2b2b2d]'}`}>{x.label}</button>;
                })}
              </div>
            </div>

            <div className="grid grid-cols-1 gap-x-4 gap-y-[18px] sm:grid-cols-2">
              <div className="flex flex-col gap-1.5 sm:col-span-2">
                <label htmlFor="kwota" className={labelCls}>Kwota kredytu</label>
                <div className="relative">
                  <input id="kwota" type="number" step={10000} value={form.kwota} onChange={(e) => set('kwota', +e.target.value)} className={`${inputCls} min-h-[48px] rounded-[7px] pr-11 text-xl font-semibold`} />
                  <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-sm text-[#5d5d60]">zł</span>
                </div>
                {bledy.kwota && <span className="text-xs text-[oklch(0.5_0.17_25)]">Kwota musi wynosić od 50 000 do 5 000 000 zł.</span>}
              </div>
              <div className="flex flex-col gap-1.5">
                <label htmlFor="n" className={labelCls}>Liczba rat</label>
                <input id="n" type="number" min={12} max={420} value={form.liczbaRat} onChange={(e) => set('liczbaRat', +e.target.value)} className={inputCls} />
                <span className={`text-xs ${bledy.liczbaRat ? 'text-[oklch(0.5_0.17_25)]' : 'text-[#5d5d60]'}`}>
                  {bledy.liczbaRat ? 'Podaj od 12 do 420 rat.' : `${Math.floor(form.liczbaRat / 12)} lat${form.liczbaRat % 12 ? ` i ${form.liczbaRat % 12} mies.` : ''}`}
                </span>
              </div>
              <div className="flex flex-col gap-1.5">
                <label htmlFor="data" className={labelCls}>Data pierwszej raty</label>
                <input id="data" type="date" value={form.dataPierwszejRaty} onChange={(e) => e.target.value && set('dataPierwszejRaty', e.target.value)} className={inputCls} />
              </div>
              <div className="flex flex-col gap-1.5">
                <span className={labelCls}>Wskaźnik referencyjny</span>
                <Seg<Wskaznik> name="wskaznik" value={form.wskaznik} onChange={(v) => setForm((f) => ({ ...f, wskaznik: v, wartoscWskaznika: WSKAZNIKI[v].domyslnie }))}
                  options={[{ v: 'POLSTR_1M', l: 'POLSTR 1M' }, { v: 'WIBOR_3M', l: 'WIBOR 3M' }]} />
              </div>
              <div className="flex flex-col gap-1.5">
                <label htmlFor="ws" className={labelCls}>Wartość wskaźnika</label>
                <div className="relative">
                  <input id="ws" type="number" step={0.01} value={form.wartoscWskaznika} onChange={(e) => set('wartoscWskaznika', +e.target.value)} className={`${inputCls} pr-8`} />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[13px] text-[#5d5d60]">%</span>
                </div>
              </div>
              <div className="flex flex-col gap-1.5">
                <label htmlFor="marza" className={labelCls}>Marża banku</label>
                <div className="relative">
                  <input id="marza" type="number" step={0.05} value={form.marza} onChange={(e) => set('marza', +e.target.value)} className={`${inputCls} pr-8`} />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[13px] text-[#5d5d60]">%</span>
                </div>
              </div>
              <div className="flex flex-col gap-1.5">
                <span className={labelCls}>Typ raty</span>
                <Seg<TypRaty> name="typ" value={form.typRaty} onChange={(v) => set('typRaty', v)} options={[{ v: 'rowne', l: 'Równe' }, { v: 'malejace', l: 'Malejące' }]} />
              </div>
            </div>

            <div className="flex flex-col gap-3 border-t border-[#1d1f20]/15 pt-5">
              <div className="flex items-center justify-between gap-3">
                <div className="flex flex-col gap-0.5">
                  <span className={labelCls}>Nadpłaty</span>
                  <span className="text-xs text-[#5d5d60]">{form.nadplaty.length ? `${form.nadplaty.length} × łącznie ${pln(form.nadplaty.reduce((a, n) => a + n.kwota, 0), 0)} zł` : 'Brak zaplanowanych nadpłat'}</span>
                </div>
                <button type="button" onClick={() => set('nadplaty', [...form.nadplaty, { id: Date.now(), nrRaty: Math.min(form.liczbaRat, (form.nadplaty.at(-1)?.nrRaty ?? 0) + 12), kwota: 20_000, efekt: 'okres' }])}
                  className="inline-flex items-center gap-1.5 rounded-md border border-[#1d1f20]/15 bg-white px-3.5 py-2 text-sm transition hover:bg-[#1d1f20]/[0.07] active:bg-[#1d1f20]/[0.14] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#5980a6]">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M5 12h14M12 5v14" /></svg>Dodaj nadpłatę
                </button>
              </div>
              {form.nadplaty.length > 0 && (
                <div className="flex flex-col gap-2.5">
                  <div className="hidden grid-cols-[90px_minmax(0,1fr)_minmax(0,1.3fr)_auto] gap-2.5 text-[11px] uppercase tracking-[0.08em] text-[#5d5d60] sm:grid"><span>Nr raty</span><span>Kwota</span><span>Efekt</span><span /></div>
                  {form.nadplaty.map((n, i) => (
                    <div key={n.id} className="grid grid-cols-2 items-start gap-2.5 sm:grid-cols-[90px_minmax(0,1fr)_minmax(0,1.3fr)_auto]">
                      <input aria-label="Nr raty" type="number" min={1} value={n.nrRaty} onChange={(e) => setNad(n.id, { nrRaty: Math.round(+e.target.value) })} className={`${inputCls} ${bledy.nad[i] ? 'border-[oklch(0.55_0.17_25)]' : ''}`} />
                      <div className="relative">
                        <input aria-label="Kwota nadpłaty" type="number" step={1000} value={n.kwota} onChange={(e) => setNad(n.id, { kwota: +e.target.value })} className={`${inputCls} pr-8`} />
                        <span className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[13px] text-[#5d5d60]">zł</span>
                      </div>
                      <select aria-label="Efekt nadpłaty" value={n.efekt} onChange={(e) => setNad(n.id, { efekt: e.target.value as EfektNadplaty })} className={`${inputCls} text-[13px]`}>
                        <option value="okres">Skraca okres</option><option value="rata">Obniża ratę</option>
                      </select>
                      <button type="button" onClick={() => set('nadplaty', form.nadplaty.filter((x) => x.id !== n.id))}
                        className="inline-flex min-h-[40px] items-center justify-center gap-1.5 rounded-md px-2.5 text-[13px] text-[oklch(0.5_0.17_25)] transition hover:bg-[oklch(0.96_0.025_25)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-[oklch(0.5_0.17_25)]">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" /></svg>Usuń
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="flex flex-wrap gap-3 pt-1">
              <button type="submit" disabled={ladowanie || maBledy} className="relative inline-flex flex-1 items-center justify-center gap-2 rounded-[7px] border border-[#5980a6] bg-[#5980a6] px-7 py-3.5 text-base font-semibold tracking-[0.02em] text-[#f2f2f3] transition hover:bg-[#597ea3] active:bg-[#416180] disabled:cursor-not-allowed disabled:opacity-45 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#5980a6]">
                <Corners />
                {ladowanie ? (<><svg className="animate-spin" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M21 12a9 9 0 1 1-6.22-8.56" /></svg>Liczenie…</>) : 'Policz'}
              </button>
              <button type="button" onClick={() => setForm({ ...PRZYKLADY[0].v, nadplaty: [] })} className="rounded-[7px] border border-[#1d1f20]/15 bg-white px-5 py-3.5 text-[15px] transition hover:bg-[#1d1f20]/[0.07]">Wyczyść</button>
            </div>
          </form>

          <section className="flex min-w-0 flex-[1.3_1_480px] flex-col gap-[18px]">
            <div className="flex flex-wrap items-baseline gap-2.5">
              <span className="font-[family-name:var(--font-head)] text-[13px] font-semibold text-[#416180]">02</span>
              <h2 className="font-[family-name:var(--font-head)] text-2xl font-semibold uppercase">Wyniki</h2>
              {wynik && (
                <span className={`ml-auto rounded-full px-2.5 py-[3px] text-[11px] ${nieaktualne ? 'bg-[#e7e7ea] text-[#2b2b2d]' : 'bg-[#eef6ff] text-[#2c455d]'}`}>
                  {nieaktualne ? 'Parametry zmienione — kliknij Policz' : `${WSKAZNIKI[form.wskaznik].label} + marża = ${pln(wynik.oprocentowanie)} %`}
                </span>
              )}
            </div>

            {blad && (
              <div role="alert" className="flex items-center gap-3 rounded-[7px] border border-[oklch(0.55_0.17_25)] bg-[oklch(0.97_0.02_25)] px-5 py-4 text-sm">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="oklch(0.5 0.17 25)" strokeWidth="1.5"><circle cx="12" cy="12" r="10" /><path d="M12 8v4M12 16h.01" /></svg>
                <span className="flex-1">{blad}</span>
                <button onClick={() => policz()} className="rounded-md border border-[oklch(0.55_0.17_25)] px-3 py-1.5 text-[13px] font-semibold text-[oklch(0.45_0.16_25)] hover:bg-white">Spróbuj ponownie</button>
              </div>
            )}

            {!wynik && !blad && (
              <div className="relative flex flex-col items-center gap-2 border border-[#1d1f20]/15 bg-white px-7 py-12 text-center">
                <Corners />
                <span className="font-[family-name:var(--font-head)] text-[22px] font-semibold uppercase">Brak wyniku</span>
                <span className="text-sm text-[#424244]">Uzupełnij parametry lub wybierz przykład i kliknij „Policz”.</span>
              </div>
            )}

            {wynik && p && (
              <div className={`flex flex-col gap-4 transition-opacity ${nieaktualne ? 'opacity-55' : ''}`}>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <Stat tone="blue" label="Rata pierwsza" value={pln(p.rataPierwsza)} unit="zł" sub={`Płatna ${dataPL(h[0].data)}`} />
                  <Stat tone="blue" label="Rata ostatnia" value={pln(p.rataOstatnia)} unit="zł" sub={`Rata nr ${h.length}, płatna ${dataPL(h[h.length - 1].data)}`} />
                  <Stat tone="graphite" label="Suma odsetek" value={pln(p.sumaOdsetek, 0)} unit="zł" sub={`${pln((p.sumaOdsetek / p.lacznieDoSplaty) * 100, 1)} % łącznej kwoty · ${pln(wynik.oprocentowanie)} % w skali roku`} />
                  <Stat tone="dark" label="Łącznie do spłaty" value={pln(p.lacznieDoSplaty, 0)} unit="zł" sub={`Kapitał ${pln(form.kwota, 0)} zł + odsetki`} />
                </div>
                {p.oszczednoscOdsetek > 1 && (
                  <div className="flex items-center gap-4 rounded-[7px] border border-[oklch(0.48_0.11_155)] bg-[oklch(0.97_0.025_155)] px-5 py-4">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="oklch(0.42 0.11 155)" strokeWidth="1.5"><path d="M20 6 9 17l-5-5" /></svg>
                    <div className="flex flex-1 flex-col gap-0.5">
                      <span className={`${kicker} tracking-[0.08em] text-[oklch(0.4_0.1_155)]`}>Efekt nadpłat</span>
                      <span className="text-sm text-[#2b2b2d]">Nadpłaty {pln(p.sumaNadplat, 0)} zł{p.skrocenieRat > 0 ? ` skracają spłatę o ${p.skrocenieRat} ${odmiana(p.skrocenieRat)}` : ' obniżają kolejne raty'}. Oszczędność na odsetkach:</span>
                    </div>
                    <span className="font-[family-name:var(--font-head)] text-[30px] font-bold text-[oklch(0.4_0.1_155)]">−{pln(p.oszczednoscOdsetek, 0)} zł</span>
                  </div>
                )}
                <div className="flex items-center gap-4 rounded-[7px] border border-[oklch(0.55_0.17_25)] bg-[oklch(0.97_0.02_25)] px-5 py-4">
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="oklch(0.5 0.17 25)" strokeWidth="1.5"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3M12 9v4M12 17h.01" /></svg>
                  <div className="flex flex-1 flex-col gap-0.5">
                    <span className={`${kicker} tracking-[0.08em] text-[oklch(0.45_0.16_25)]`}>Ryzyko stopy procentowej</span>
                    <span className="text-sm text-[#2b2b2d]">Przy wzroście wskaźnika o 2,5 p.p. ({pln(wynik.oprocentowanie + 2.5)} %) pierwsza rata wyniesie {pln(p.rataStresTest)} zł.</span>
                  </div>
                  <span className="font-[family-name:var(--font-head)] text-[26px] font-bold text-[oklch(0.45_0.16_25)]">+{pln(p.rataStresTest - p.rataPierwsza)} zł</span>
                </div>
              </div>
            )}
          </section>
        </div>

        <section className="flex flex-col gap-[18px]">
          <div className="flex flex-wrap items-end gap-4">
            <div className="mr-auto flex items-baseline gap-2.5">
              <span className="font-[family-name:var(--font-head)] text-[13px] font-semibold text-[#416180]">03</span>
              <h2 className="font-[family-name:var(--font-head)] text-[28px] font-semibold uppercase">Harmonogram spłaty</h2>
              {wynik && <span className="text-sm text-[#5d5d60]">{widok === 'mies' ? `raty ${(rok - 1) * 12 + 1}–${Math.min(rok * 12, h.length)} z ${h.length}` : `${h.length} rat, sumy roczne`}</span>}
            </div>
            {widok === 'mies' && wynik && (
              <div className="flex items-center gap-2">
                <button aria-label="Poprzedni rok" onClick={() => setRok((r) => Math.max(1, r - 1))} className="grid h-9 w-9 place-items-center rounded-md border border-[#1d1f20]/15 bg-white hover:bg-[#1d1f20]/[0.07]"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="m15 18-6-6 6-6" /></svg></button>
                <span className="min-w-[90px] text-center font-[family-name:var(--font-head)] font-semibold">Rok {rok} / {lat}</span>
                <button aria-label="Następny rok" onClick={() => setRok((r) => Math.min(lat, r + 1))} className="grid h-9 w-9 place-items-center rounded-md border border-[#1d1f20]/15 bg-white hover:bg-[#1d1f20]/[0.07]"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="m9 18 6-6-6-6" /></svg></button>
              </div>
            )}
            <div className="w-[220px]"><Seg name="widok" value={widok} onChange={setWidok} options={[{ v: 'rok', l: 'Rocznie' }, { v: 'mies', l: 'Miesięcznie' }]} /></div>
            <button onClick={eksportujCsv} disabled={!wynik || ladowanie} className="inline-flex min-h-[42px] items-center gap-1.5 rounded-md border border-[#1d1f20]/15 bg-white px-3.5 text-sm transition hover:bg-[#1d1f20]/[0.07] disabled:cursor-not-allowed disabled:opacity-45">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M12 15V3M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5" /></svg>Eksportuj CSV
            </button>
          </div>

          <div className="relative border border-[#1d1f20]/15 bg-white">
            <Corners />
            <div className="max-h-[520px] overflow-auto overscroll-contain">
              <table className="w-full min-w-[720px] border-separate border-spacing-0 text-[15px] tabular-nums">
                <thead>
                  <tr className="text-[11px] uppercase tracking-[0.08em] text-[#1d1f20]/60">
                    {[widok === 'mies' ? 'Nr' : 'Rok', 'Data', 'Kapitał', 'Odsetki', 'Rata', 'Saldo po spłacie'].map((c, i) => (
                      <th key={c} className={`sticky top-0 border-b border-[#1d1f20]/15 bg-[#f5f5f8] px-4 py-3 font-normal ${i === 0 ? 'left-0 z-30 w-[72px] text-left' : i === 1 ? 'z-20 text-left' : 'z-20 text-right'}`}>{c}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {wiersze.map((w) => (
                    <tr key={w.key} className={w.ost ? 'bg-[#eef6ff]' : 'hover:bg-[#1d1f20]/[0.04]'}>
                      <td className={`sticky left-0 z-10 border-b border-[#1d1f20]/[0.08] px-4 py-[11px] ${w.ost ? 'bg-[#eef6ff] font-bold text-[#1d2d3d] shadow-[inset_3px_0_0_#416180]' : 'bg-white text-[#5d5d60]'}`}>{w.nr}</td>
                      <td className="whitespace-nowrap border-b border-[#1d1f20]/[0.08] px-4 py-[11px]">
                        <div className="flex flex-wrap items-center gap-2">{w.data}{w.ost && <span className="rounded-full bg-[#416180] px-2.5 py-[3px] text-[11px] font-semibold text-white">{widok === 'mies' ? 'Ostatnia rata' : 'Ostatni rok'}</span>}</div>
                      </td>
                      <td className="border-b border-[#1d1f20]/[0.08] px-4 py-[11px] text-right">
                        <div>{w.kap}</div>
                        {w.nad > 0 && <div className="text-xs font-semibold text-[oklch(0.42_0.11_155)]">+ nadpłata {pln(w.nad, widok === 'mies' ? 2 : 0)}</div>}
                      </td>
                      <td className="border-b border-[#1d1f20]/[0.08] px-4 py-[11px] text-right text-[#424244]">{w.ods}</td>
                      <td className={`border-b border-[#1d1f20]/[0.08] px-4 py-[11px] text-right font-semibold ${w.ost ? 'text-[#1d2d3d]' : ''}`}>{w.rata}</td>
                      <td className={`border-b border-[#1d1f20]/[0.08] px-4 py-[11px] text-right ${w.ost ? 'font-bold' : ''}`}>{w.saldo}</td>
                    </tr>
                  ))}
                  {!wynik && <tr><td colSpan={6} className="px-4 py-10 text-center text-sm text-[#5d5d60]">Harmonogram pojawi się po obliczeniu.</td></tr>}
                </tbody>
              </table>
            </div>
            <div className="flex flex-wrap justify-between gap-3 border-t border-[#1d1f20]/15 px-4 py-2.5 text-xs text-[#5d5d60]">
              <span>Kwoty w zł. Przewiń tabelę, aby zobaczyć kolejne pozycje.</span>
              {wynik && <span>Ostatnia rata: nr {h.length}, {dataPL(h[h.length - 1].data)} · {pln(p!.rataOstatnia)} zł</span>}
            </div>
          </div>
          <p className="max-w-[820px] text-xs leading-normal text-[#5d5d60]">Wartości wskaźników są przykładowe. Symulacja zakłada stałą wartość wskaźnika przez cały okres kredytowania i nie uwzględnia prowizji, ubezpieczeń ani kosztów wyceny nieruchomości.</p>
        </section>
      </main>
    </div>
  );
}
