import { NextResponse } from 'next/server';
import { policzHarmonogram, walidacja, type HarmonogramRequest } from '@/lib/harmonogram';

export async function POST(request: Request) {
  let body: HarmonogramRequest;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ bledy: ['json'] }, { status: 400 });
  }
  body.nadplaty = Array.isArray(body.nadplaty) ? body.nadplaty : [];
  const bledy = walidacja(body);
  if (bledy.length) return NextResponse.json({ bledy }, { status: 422 });
  return NextResponse.json(policzHarmonogram(body));
}
